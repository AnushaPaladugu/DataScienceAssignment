# DataScienceAssignment
Data Science Assignment with EDA, Lookalike Model, and Customer Segmentation
